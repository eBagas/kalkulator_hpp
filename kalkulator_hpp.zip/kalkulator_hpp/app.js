// ===== HPP Calculator — Main Application Logic =====

(function () {
  'use strict';

  // ===== DOM REFERENCES =====
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  // Pages
  const pages = {
    dashboard: $('#page-dashboard'),
    calculator: $('#page-calculator'),
    history: $('#page-history'),
  };

  // Nav items
  const navItems = $$('.nav-item');

  // Sidebar / Mobile
  const sidebar = $('#sidebar');
  const overlay = $('#sidebar-overlay');
  const menuToggle = $('#menu-toggle');

  // Step elements
  const steps = $$('.stepper .step');
  const formSteps = $$('.form-step');

  // Toggle groups
  const toggleMode = $('#toggle-mode');
  const toggleBeban = $('#toggle-beban');

  // Inputs (Step 1)
  const inputNama = $('#input-nama-produk');
  const inputJumlah = $('#input-jumlah');
  const inputHargaBeli = $('#input-harga-beli');
  const inputOngkir = $('#input-ongkir');
  const inputBongkar = $('#input-bongkar');
  const inputUM = $('#input-um');
  const inputLainnya = $('#input-lainnya');

  // Inputs (Step 2)
  const inputBebanPersen = $('#input-beban-persen');
  const inputBebanFlat = $('#input-beban-flat');
  const inputMarginKonsumen = $('#input-margin-konsumen');
  const inputMarginReseller = $('#input-margin-reseller');

  // Groups
  const groupJumlah = $('#group-jumlah');
  const groupBebanPersen = $('#group-beban-persen');
  const groupBebanFlat = $('#group-beban-flat');
  const labelBeliHint = $('#label-beli-hint');

  // Preview
  const previewTotal = $('#preview-total');
  const previewUnit = $('#preview-unit');
  const bannerHppUnit = $('#banner-hpp-unit');

  // Results
  const resultEls = {
    productName: $('#result-product-name'),
    hargaBeli: $('#res-harga-beli'),
    ongkir: $('#res-ongkir'),
    bongkar: $('#res-bongkar'),
    um: $('#res-um'),
    lainnya: $('#res-lainnya'),
    totalHpp: $('#res-total-hpp'),
    hppUnit: $('#res-hpp-unit'),
    beban: $('#res-beban'),
    modalBeban: $('#res-modal-beban'),
    hargaKonsumen: $('#res-harga-konsumen'),
    marginKonsumenPct: $('#res-margin-konsumen-pct'),
    profitKonsumen: $('#res-profit-konsumen'),
    hargaReseller: $('#res-harga-reseller'),
    marginResellerPct: $('#res-margin-reseller-pct'),
    profitReseller: $('#res-profit-reseller'),
  };

  // Dashboard stats
  const statTotal = $('#stat-total');
  const statAvgHpp = $('#stat-avg-hpp');
  const statAvgMargin = $('#stat-avg-margin');

  // State
  let currentPage = 'dashboard';
  let currentStep = 1;
  let calcMode = 'batch'; // 'batch' | 'unit'
  let bebanMode = 'persen'; // 'persen' | 'flat'
  let history = [];

  // ===== UTILITIES =====

  function formatRupiah(num) {
    if (isNaN(num) || num === 0) return 'Rp 0';
    const rounded = Math.round(num);
    return 'Rp ' + rounded.toLocaleString('id-ID');
  }

  function parseNumber(str) {
    if (!str) return 0;
    // Remove thousands separators and whitespace
    const cleaned = str.replace(/[^\d]/g, '');
    return parseInt(cleaned, 10) || 0;
  }

  function parseDecimal(str) {
    if (!str) return 0;
    const cleaned = str.replace(/,/g, '.').replace(/[^\d.]/g, '');
    return parseFloat(cleaned) || 0;
  }

  function autoFormatCurrency(input) {
    const raw = input.value.replace(/[^\d]/g, '');
    if (!raw) {
      input.value = '';
      return;
    }
    const num = parseInt(raw, 10);
    input.value = num.toLocaleString('id-ID');
  }

  function showToast(message) {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ===== NAVIGATION =====

  function navigateTo(page) {
    currentPage = page;

    // Update nav active state
    navItems.forEach((item) => {
      item.classList.toggle('active', item.dataset.page === page);
    });

    // Show correct page
    Object.keys(pages).forEach((key) => {
      pages[key].classList.toggle('active', key === page);
    });

    // Close mobile sidebar
    closeSidebar();

    // If navigating to calculator, reset to step 1
    if (page === 'calculator') {
      resetCalculator();
    }

    // If navigating to dashboard, refresh stats
    if (page === 'dashboard') {
      renderDashboard();
    }

    // If navigating to history, render history
    if (page === 'history') {
      renderHistory();
    }
  }

  function closeSidebar() {
    sidebar.classList.remove('open');
    overlay.classList.remove('active');
  }

  // ===== STEPPER =====

  function goToStep(step) {
    currentStep = step;

    // Update stepper visual
    steps.forEach((el, i) => {
      const stepNum = i + 1;
      el.classList.remove('active', 'completed');
      if (stepNum === step) el.classList.add('active');
      if (stepNum < step) el.classList.add('completed');
    });

    // Show form step
    formSteps.forEach((el) => {
      el.classList.remove('active');
    });
    $(`#step-${step}`).classList.add('active');
  }

  // ===== HPP CALCULATION =====

  function getHPPData() {
    const hargaBeli = parseNumber(inputHargaBeli.value);
    const ongkir = parseNumber(inputOngkir.value);
    const bongkar = parseNumber(inputBongkar.value);
    const um = parseNumber(inputUM.value);
    const lainnya = parseNumber(inputLainnya.value);
    const jumlah = calcMode === 'batch' ? Math.max(parseNumber(inputJumlah.value), 1) : 1;

    const totalHPP = hargaBeli + ongkir + bongkar + um + lainnya;
    const hppPerUnit = totalHPP / jumlah;

    return { hargaBeli, ongkir, bongkar, um, lainnya, jumlah, totalHPP, hppPerUnit };
  }

  function updateHPPPreview() {
    const { totalHPP, hppPerUnit } = getHPPData();
    previewTotal.textContent = formatRupiah(totalHPP);
    previewUnit.textContent = formatRupiah(hppPerUnit);
  }

  // ===== FULL CALCULATION =====

  function calculateFull() {
    const hpp = getHPPData();
    const nama = inputNama.value.trim() || 'Produk Tanpa Nama';

    // Beban operasional per unit
    let bebanPerUnit = 0;
    if (bebanMode === 'persen') {
      const pct = parseDecimal(inputBebanPersen.value);
      bebanPerUnit = (hpp.hppPerUnit * pct) / 100;
    } else {
      bebanPerUnit = parseNumber(inputBebanFlat.value);
    }

    const modalBeban = hpp.hppPerUnit + bebanPerUnit;

    // Margins
    const marginKonsumen = parseDecimal(inputMarginKonsumen.value);
    const marginReseller = parseDecimal(inputMarginReseller.value);

    const hargaKonsumen = modalBeban * (1 + marginKonsumen / 100);
    const hargaReseller = modalBeban * (1 + marginReseller / 100);

    const profitKonsumen = hargaKonsumen - modalBeban;
    const profitReseller = hargaReseller - modalBeban;

    return {
      nama,
      ...hpp,
      bebanPerUnit,
      modalBeban,
      marginKonsumen,
      marginReseller,
      hargaKonsumen,
      hargaReseller,
      profitKonsumen,
      profitReseller,
      timestamp: Date.now(),
    };
  }

  function displayResults(data) {
    resultEls.productName.textContent = data.nama;
    resultEls.hargaBeli.textContent = formatRupiah(data.hargaBeli);
    resultEls.ongkir.textContent = formatRupiah(data.ongkir);
    resultEls.bongkar.textContent = formatRupiah(data.bongkar);
    resultEls.um.textContent = formatRupiah(data.um);
    resultEls.lainnya.textContent = formatRupiah(data.lainnya);
    resultEls.totalHpp.textContent = formatRupiah(data.totalHPP);
    resultEls.hppUnit.textContent = formatRupiah(data.hppPerUnit);
    resultEls.beban.textContent = formatRupiah(data.bebanPerUnit);
    resultEls.modalBeban.textContent = formatRupiah(data.modalBeban);
    resultEls.hargaKonsumen.textContent = formatRupiah(data.hargaKonsumen);
    resultEls.marginKonsumenPct.textContent = data.marginKonsumen + '%';
    resultEls.profitKonsumen.textContent = formatRupiah(data.profitKonsumen);
    resultEls.hargaReseller.textContent = formatRupiah(data.hargaReseller);
    resultEls.marginResellerPct.textContent = data.marginReseller + '%';
    resultEls.profitReseller.textContent = formatRupiah(data.profitReseller);
  }

  // ===== HISTORY (localStorage) =====

  function loadHistory() {
    try {
      history = JSON.parse(localStorage.getItem('hpp_history') || '[]');
    } catch {
      history = [];
    }
  }

  function saveHistory() {
    localStorage.setItem('hpp_history', JSON.stringify(history));
  }

  function addToHistory(data) {
    history.unshift(data);
    // Keep max 50
    if (history.length > 50) history.pop();
    saveHistory();
  }

  function deleteFromHistory(index) {
    history.splice(index, 1);
    saveHistory();
    renderHistory();
    renderDashboard();
  }

  function clearAllHistory() {
    if (!confirm('Hapus semua riwayat kalkulasi?')) return;
    history = [];
    saveHistory();
    renderHistory();
    renderDashboard();
    showToast('Riwayat berhasil dihapus');
  }

  function formatDate(ts) {
    const d = new Date(ts);
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  function renderHistoryItem(data, index) {
    const div = document.createElement('div');
    div.className = 'history-item';
    div.innerHTML = `
      <div class="history-item-header">
        <span class="history-item-name">${escapeHtml(data.nama)}</span>
        <span class="history-item-date">${formatDate(data.timestamp)}</span>
      </div>
      <div class="history-item-prices">
        <div class="history-price">
          <span class="history-price-label">HPP/Unit</span>
          <span class="history-price-value amber">${formatRupiah(data.hppPerUnit)}</span>
        </div>
        <div class="history-price">
          <span class="history-price-label">Konsumen</span>
          <span class="history-price-value green">${formatRupiah(data.hargaKonsumen)}</span>
        </div>
        <div class="history-price">
          <span class="history-price-label">Reseller</span>
          <span class="history-price-value teal">${formatRupiah(data.hargaReseller)}</span>
        </div>
      </div>
      <div class="history-item-actions">
        <button class="history-btn" data-action="view" data-index="${index}">Lihat Detail</button>
        <button class="history-btn delete" data-action="delete" data-index="${index}">Hapus</button>
      </div>
    `;
    return div;
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function renderHistory() {
    const container = $('#history-list');
    container.innerHTML = '';

    if (history.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.4">
            <circle cx="12" cy="12" r="10"/>
            <polyline points="12 6 12 12 16 14"/>
          </svg>
          <p>Belum ada riwayat kalkulasi.</p>
        </div>
      `;
      return;
    }

    history.forEach((item, i) => {
      container.appendChild(renderHistoryItem(item, i));
    });
  }

  function renderRecentHistory() {
    const container = $('#recent-history-list');
    container.innerHTML = '';

    if (history.length === 0) {
      container.innerHTML = `
        <div class="empty-state" id="dashboard-empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" opacity="0.4">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
            <polyline points="14 2 14 8 20 8"/>
            <line x1="16" y1="13" x2="8" y2="13"/>
            <line x1="16" y1="17" x2="8" y2="17"/>
          </svg>
          <p>Belum ada kalkulasi. Mulai hitung HPP pertama Anda!</p>
        </div>
      `;
      return;
    }

    const recent = history.slice(0, 3);
    recent.forEach((item, i) => {
      container.appendChild(renderHistoryItem(item, i));
    });
  }

  function renderDashboard() {
    // Stats
    statTotal.textContent = history.length;

    if (history.length > 0) {
      const avgHpp = history.reduce((s, h) => s + h.hppPerUnit, 0) / history.length;
      statAvgHpp.textContent = formatRupiah(avgHpp);

      const avgMargin = history.reduce((s, h) => s + h.marginKonsumen, 0) / history.length;
      statAvgMargin.textContent = Math.round(avgMargin) + '%';
    } else {
      statAvgHpp.textContent = 'Rp 0';
      statAvgMargin.textContent = '0%';
    }

    renderRecentHistory();
  }

  // ===== VIEW DETAIL (load into calculator results) =====

  function viewDetail(index) {
    const data = history[index];
    if (!data) return;

    navigateTo('calculator');

    // Jump directly to step 3 with the data
    displayResults(data);
    goToStep(3);
  }

  // ===== RESET CALCULATOR =====

  function resetCalculator() {
    currentStep = 1;
    goToStep(1);

    // Clear all inputs
    inputNama.value = '';
    inputJumlah.value = '';
    inputHargaBeli.value = '';
    inputOngkir.value = '';
    inputBongkar.value = '';
    inputUM.value = '';
    inputLainnya.value = '';
    inputBebanPersen.value = '';
    inputBebanFlat.value = '';
    inputMarginKonsumen.value = '';
    inputMarginReseller.value = '';

    // Reset mode toggles
    calcMode = 'batch';
    bebanMode = 'persen';
    updateToggleUI();
    updateHPPPreview();
  }

  function updateToggleUI() {
    // Mode toggle
    toggleMode.querySelectorAll('.toggle-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.mode === calcMode);
    });
    groupJumlah.classList.toggle('hidden', calcMode === 'unit');
    labelBeliHint.textContent = calcMode === 'batch' ? '(total batch)' : '(per unit)';

    // Beban toggle
    toggleBeban.querySelectorAll('.toggle-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.beban === bebanMode);
    });
    groupBebanPersen.classList.toggle('hidden', bebanMode !== 'persen');
    groupBebanFlat.classList.toggle('hidden', bebanMode !== 'flat');
  }

  // ===== EVENT LISTENERS =====

  // Navigation
  navItems.forEach((item) => {
    item.addEventListener('click', () => navigateTo(item.dataset.page));
  });

  // Mobile menu
  menuToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('active');
  });

  overlay.addEventListener('click', closeSidebar);

  // CTA
  $('#cta-new-calc').addEventListener('click', () => navigateTo('calculator'));

  // Mode toggle (batch/unit)
  toggleMode.addEventListener('click', (e) => {
    const btn = e.target.closest('.toggle-btn');
    if (!btn) return;
    calcMode = btn.dataset.mode;
    updateToggleUI();
    updateHPPPreview();
  });

  // Beban toggle
  toggleBeban.addEventListener('click', (e) => {
    const btn = e.target.closest('.toggle-btn');
    if (!btn) return;
    bebanMode = btn.dataset.beban;
    updateToggleUI();
  });

  // Currency auto-format on all currency inputs
  const currencyInputs = [inputHargaBeli, inputOngkir, inputBongkar, inputUM, inputLainnya, inputBebanFlat];
  currencyInputs.forEach((input) => {
    input.addEventListener('input', () => {
      autoFormatCurrency(input);
      updateHPPPreview();
    });
  });

  // Numeric input for jumlah
  inputJumlah.addEventListener('input', () => {
    autoFormatCurrency(inputJumlah);
    updateHPPPreview();
  });

  // Clear buttons
  $$('.clear-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.target);
      if (target) {
        target.value = '';
        updateHPPPreview();
        target.focus();
      }
    });
  });

  // Step 1 → 2
  $('#btn-step1-next').addEventListener('click', () => {
    const hpp = getHPPData();
    bannerHppUnit.textContent = formatRupiah(hpp.hppPerUnit);
    goToStep(2);
  });

  // Step 2 → back to 1
  $('#btn-step2-back').addEventListener('click', () => goToStep(1));

  // Step 2 → 3 (calculate)
  $('#btn-step2-next').addEventListener('click', () => {
    const data = calculateFull();
    displayResults(data);
    goToStep(3);
  });

  // Step 3 → back to 2
  $('#btn-step3-back').addEventListener('click', () => goToStep(2));

  // Save & new
  $('#btn-save').addEventListener('click', () => {
    const data = calculateFull();
    addToHistory(data);
    showToast('Kalkulasi berhasil disimpan!');
    resetCalculator();
    navigateTo('dashboard');
  });

  // History event delegation
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;

    const action = btn.dataset.action;
    const index = parseInt(btn.dataset.index, 10);

    if (action === 'view') viewDetail(index);
    if (action === 'delete') {
      deleteFromHistory(index);
      showToast('Kalkulasi dihapus');
    }
  });

  // Clear all history
  $('#btn-clear-history').addEventListener('click', clearAllHistory);

  // ===== INIT =====
  loadHistory();
  renderDashboard();
})();
